namespace google {
namespace protobuf {
namespace internal {

bool fully_verify_message_sets_opt_out = true;

}  // namespace internal
}  // namespace protobuf
}  // namespace google
